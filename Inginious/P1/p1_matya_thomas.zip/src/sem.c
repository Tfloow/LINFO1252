#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "sem.h"


int main(int argc, char** argv){

    test();

    return EXIT_SUCCESS;
}
